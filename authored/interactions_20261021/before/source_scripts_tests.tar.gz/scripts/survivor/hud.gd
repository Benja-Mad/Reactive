## The HUD in the crew's pixel kit: your face and health, the clock, the count, experience along
## the top, and the program as glyphs in the corner, each trigger refilling as it recharges. No
## sentences while playing. Level-ups offer three cards; the pause opens the workshop.
extends Control
const Kit = preload("res://scripts/ui/kit.gd")
const Build = preload("res://scripts/survivor/build.gd")
const NodeEditor = preload("res://scripts/survivor/node_editor.gd")
const Portraits = preload("res://ui/operator_portraits.gd")
const PX: float = Kit.PX
const CARD := Vector2(128, 112) * Kit.PX
var run: Node
var _key: String = ""
var _controls: Control
var _choices: Array = []
## Level-up: the piece chosen from the offers, waiting for a destination.
var _picking: String = ""
var _hotkeys: Array[Callable] = []
var _editor: Control
var _faces: Dictionary = {}

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	theme = Kit.theme()
	_controls = Control.new()
	_controls.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_controls)

func my_build() -> Dictionary:
	return run.builds.get(multiplayer.get_unique_id(), Build.fresh())

func _process(_delta: float) -> void:
	size = get_viewport_rect().size
	_controls.size = size
	_choices = run.offers.get(multiplayer.get_unique_id(), [])
	if run.phase != "upgrade" or _picking not in _choices: _picking = ""
	var key: String = "%s|%s|%s|%s|%s" % [run.phase, _choices, my_build(), _picking, size]
	if key != _key:
		_key = key
		_rebuild()
	queue_redraw()

## A routine written in one line of shorthand: «near › raise · cold › relay».
static func shorthand(routine: Dictionary) -> String:
	var steps: Array = routine["steps"].map(func(key: String) -> String: return Build.PIECES[key]["name"])
	var parts: Array[String] = [Build.PIECES[routine["when"]]["name"] if routine["when"] != "" else "—", " · ".join(steps) if not steps.is_empty() else Build.Recipe.FROM[routine.get("from", "water")]]
	if routine["then"] != "": parts.append(Build.PIECES[routine["then"]]["name"])
	return "  ›  ".join(parts)

func _face(role_support: bool) -> Texture2D:
	var role: int = Statics.Role.SUPPORT if role_support else Statics.Role.DAMAGE
	if not _faces.has(role): _faces[role] = Portraits.portrait(role, true)
	return _faces[role]

# --- Playing ------------------------------------------------------------------------------------

func _draw() -> void:
	if run == null: return
	var player: Character = run.local_player()
	var support: bool = player is Support
	var accent: String = "do" if support else "when"
	var health: float = player.health if player != null else 100.0
	# Experience along the top edge.
	var fill: float = clampf(float(run.xp) / Build.threshold(run.level), 0, 1)
	draw_rect(Rect2(0, 0, size.x, 4 * PX), Kit.INK)
	draw_rect(Rect2(0, 0, roundf(size.x * fill / PX) * PX, 3 * PX), Kit.RAMPS["tool"][1])
	draw_rect(Rect2(0, 0, roundf(size.x * fill / PX) * PX, PX), Kit.RAMPS["tool"][2])
	for i: int in range(1, 20): draw_rect(Rect2(roundf(size.x * i / 20.0 / PX) * PX, 0, PX, 3 * PX), Kit.INK)
	# You: face, health and level.
	var card := Rect2(Vector2(8, 12) * PX, Vector2(96, 30) * PX)
	Kit.panel(self, card, accent if health > 25 else "danger")
	var face_box := Rect2(card.position + Vector2(4, 3) * PX, Vector2(24, 24) * PX)
	draw_rect(face_box, Kit.INK)
	draw_rect(face_box.grow(-PX), Kit.BOARD)
	# The bust at the yard's own grain: one texel a canvas unit.
	var face := _face(support) as AtlasTexture
	draw_texture_rect_region(face.atlas, Rect2(face_box.position + Vector2(PX, PX), Vector2(44, 44)), Rect2(face.region.position + Vector2(2, 0), Vector2(44, 44)))
	Kit.bar(self, card.position + Vector2(33, 8) * PX, 10, health / 10.0, accent if health > 25 else "danger", 5, 6)
	Kit.tape(self, card.position + Vector2(33, 17) * PX, "%d" % run.level, "tool")
	# The rest of the crew: their colour is their name.
	var y: float = card.end.y + 6 * PX
	for other: Node in run.players():
		if other == player: continue
		var mate: Character = other
		var mate_accent: String = "do" if mate is Support else "when"
		draw_rect(Rect2(Vector2(12 * PX, y), Vector2(3, 5) * PX), Kit.ramp(mate_accent)[1])
		Kit.bar(self, Vector2(19 * PX, y), 10, mate.health / 10.0 if not mate.eliminated else 0.0, mate_accent, 4, 4)
		y += 9 * PX
	# Clock and count.
	var remaining: int = maxi(0, ceili(run.DURATION - run.elapsed))
	var clock := Rect2(Vector2(roundf(size.x * 0.5 / PX) * PX - 36 * PX, 10 * PX), Vector2(72, 22) * PX)
	Kit.panel(self, clock, "tool")
	Kit.text(self, Vector2(clock.get_center().x, clock.position.y - 3 * PX), "%02d:%02d" % [remaining / 60, remaining % 60], Kit.TEXT if remaining > 30 else Kit.RAMPS["danger"][2], 2, HORIZONTAL_ALIGNMENT_CENTER)
	var count := Rect2(Vector2(size.x - 76 * PX, 12 * PX), Vector2(68, 22) * PX)
	Kit.panel(self, count, "danger")
	draw_texture_rect(Kit.icon("derribo", "danger"), Rect2(count.position + Vector2(5, 5) * PX, Vector2(12, 12) * PX), false)
	Kit.text(self, Vector2(count.end.x - 6 * PX, count.position.y - 3 * PX), "%03d" % run.kills, Kit.TEXT, 2, HORIZONTAL_ALIGNMENT_RIGHT)
	_draw_program()
	if run.elapsed < 14 and run.phase == "running": _draw_hints()
	if player != null and player.eliminated and run.phase == "running":
		var label: String = "FUERA DE SERVICIO"
		Kit.tape(self, Vector2(size.x * 0.5 - (Kit.width(label) + 8 * PX) * 0.5, size.y * 0.42), label, "danger")
	if run.phase != "running": _draw_sheet()

## The program in the corner: the weapon and its pieces, then one row of glyphs per routine. The trigger refills from the bottom as
## it recharges and lights up when ready; a broken routine carries a rose mark, and one waiting
## for its matter (none within reach, none carried) that source's glyph in rose.
func _draw_program() -> void:
	var routines: Array = my_build()["routines"]
	var attack: Array = Build.attack_steps(my_build())
	var charge: Array = run.charges.get(multiplayer.get_unique_id(), [])
	var widest: int = 1 + attack.size()
	for routine: Dictionary in routines: widest = maxi(widest, 2 + routine["steps"].size() + (1 if routine["then"] != "" else 0))
	widest += 1
	var rows: int = routines.size() + 1
	var box := Rect2(Vector2(8 * PX, size.y - (rows * 15 + 10) * PX), Vector2((widest * 17 + 14) * PX, (rows * 15 + 4) * PX))
	Kit.panel(self, box, "do")
	_draw_reserve(Vector2(box.position.x, box.position.y - 20 * PX))
	# The weapon first, with what is plugged into it, ruled off from the routines.
	var support: bool = run.local_player() is Support
	var weapon_at := Vector2(box.position.x + 5 * PX, box.position.y + 3 * PX)
	Kit.notched(self, Rect2(weapon_at, Vector2(14, 14) * PX), Kit.FILL_HI, Kit.ramp("do" if support else "when")[1])
	draw_texture_rect(Kit.icon("agua" if support else "fuego", "do" if support else "when"), Rect2(weapon_at + Vector2(PX, PX), Vector2(12, 12) * PX), false)
	for i: int in attack.size():
		var spot := Vector2(weapon_at.x + (19 + i * 17) * PX, weapon_at.y)
		draw_rect(Rect2(spot.x - 3 * PX, weapon_at.y + 6 * PX, 3 * PX, PX), Kit.ramp("do")[0])
		Kit.notched(self, Rect2(spot, Vector2(14, 14) * PX), Kit.FILL_HI, Kit.INK)
		draw_texture_rect(Kit.icon(attack[i]), Rect2(spot + Vector2(PX, PX), Vector2(12, 12) * PX), false)
	draw_rect(Rect2(box.position.x + 3 * PX, box.position.y + 17 * PX, box.size.x - 6 * PX, PX), Kit.LINE)
	for index: int in routines.size():
		var routine: Dictionary = routines[index]
		var at := Vector2(box.position.x + 5 * PX, box.position.y + (3 + (index + 1) * 15) * PX)
		if routine["when"] == "":
			for i: int in 3: Kit.dashed(self, Rect2(at + Vector2(i * 17 * PX, 0), Vector2(14, 14) * PX), Kit.LINE_HI)
			continue
		var ready: float = float(charge[index]) if index < charge.size() else 0.0
		var dry: bool = ready < 0.0
		if dry: ready = 0.0
		var pieces: Array = [routine["when"]] + routine["steps"]
		if routine["then"] != "": pieces.append(routine["then"])
		var x: float = at.x
		for i: int in pieces.size():
			var key: String = pieces[i]
			if i > 0: draw_rect(Rect2(x - 3 * PX, at.y + 6 * PX, 3 * PX, PX), Kit.ramp(Kit.accent_of(key))[0])
			var lit: bool = i == 0 and ready >= 1.0
			Kit.notched(self, Rect2(Vector2(x, at.y), Vector2(14, 14) * PX), Kit.FILL_HI, Kit.RAMPS["when"][1] if lit else Kit.INK)
			var spot := Rect2(Vector2(x, at.y) + Vector2(PX, PX), Vector2(12, 12) * PX)
			if i == 0 and ready < 1.0:
				# Recharging: the glyph stays readable in grey and its colour fills up from below.
				draw_texture_rect(Kit.icon(key, "mute"), spot, false)
				var filled: float = floorf(ready * 12.0)
				var tex := Kit.icon(key)
				if filled > 0.0:
					draw_texture_rect_region(tex.atlas, Rect2(spot.position + Vector2(0, (12.0 - filled) * PX), Vector2(12, filled) * PX), Rect2(tex.region.position + Vector2(0, 12.0 - filled), Vector2(12, filled)))
			else:
				draw_texture_rect(Kit.icon(key), spot, false)
			x += (19 if i == 0 else 17) * PX
		if dry:
			draw_texture_rect(Kit.icon(SOURCE_GLYPH[routine.get("from", "water")], "danger"), Rect2(Vector2(x, at.y) + Vector2(PX, PX), Vector2(12, 12) * PX), false)
			x += 15 * PX
		if Build.problem(routine, routines, index) != "":
			Kit.text(self, Vector2(x - 2 * PX, at.y), "!", Kit.RAMPS["danger"][1])

const SOURCE_GLYPH := {"water": "agua", "fire": "fuego", "current": "arco", "scrap": "chatarra"}
const SOURCE_ACCENT := {"water": "do", "fire": "when", "current": "tool", "scrap": "mute"}
## What you carry, over the program: each substance's glyph and a pip per draught. A full pocket
## lights all three; an empty one is a grey glyph, so a routine marked dry says why at a glance.
func _draw_reserve(at: Vector2) -> void:
	var reserve: Dictionary = run.reserves.get(multiplayer.get_unique_id(), {})
	if reserve.is_empty(): return
	var box := Rect2(at, Vector2(4 * 30 + 6, 18) * PX)
	Kit.panel(self, box, "tool")
	var x: float = at.x + 4 * PX
	for substance: String in ["water", "fire", "current", "scrap"]:
		var held: int = int(reserve.get(substance, 0))
		var accent: String = SOURCE_ACCENT[substance]
		draw_texture_rect(Kit.icon(SOURCE_GLYPH[substance], accent if held > 0 else "mute"), Rect2(Vector2(x, at.y + 3 * PX), Vector2(12, 12) * PX), false)
		for pip: int in run.RESERVE_MAX:
			var spot := Rect2(Vector2(x + (14 + pip * 4) * PX, at.y + 5 * PX), Vector2(3, 8) * PX)
			draw_rect(spot, Kit.INK)
			if pip < held: draw_rect(spot, Kit.ramp(accent)[2 if substance == "scrap" else 1])
		x += 30 * PX

func _draw_hints() -> void:
	var pairs: Array = [["WASD", "mover"], ["Esc", "taller"]]
	var total: float = 0.0
	for pair: Array in pairs: total += maxf(9.0 * PX, Kit.width(pair[0]) + 6 * PX) + 4 * PX + Kit.width(pair[1]) + 10 * PX
	var x: float = roundf((size.x - total) * 0.5 / PX) * PX
	var y: float = size.y - 20 * PX
	for pair: Array in pairs:
		x += Kit.keycap(self, Vector2(x, y), pair[0]) + 4 * PX
		Kit.text(self, Vector2(x, y - 2 * PX), pair[1], Kit.DIM, 1, HORIZONTAL_ALIGNMENT_LEFT, true)
		x += Kit.width(pair[1]) + 10 * PX

# --- Sheets: level-up, workshop, end of shift ----------------------------------------------------

func _draw_sheet() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(Kit.INK, 0.45))
	Kit.dither(self, Rect2(Vector2.ZERO, size), Kit.INK, 0.4)
	if run.phase in ["won", "lost"]:
		var panel := _end_rect()
		Kit.panel(self, panel, "tool" if run.phase == "won" else "danger", "RELEVO" if run.phase == "won" else "TURNO PERDIDO")
		var cx: float = panel.get_center().x
		var y: float = panel.position.y + 18 * PX
		var stats: Array = [["cada", "%02d:%02d" % [int(run.elapsed) / 60, int(run.elapsed) % 60]], ["derribo", "%d" % run.kills], ["otra", "%d" % run.level]]
		var step: float = panel.size.x / 3.0
		for i: int in stats.size():
			var sx: float = panel.position.x + step * (i + 0.5)
			draw_texture_rect(Kit.icon(stats[i][0], "danger" if stats[i][0] == "derribo" else "tool"), Rect2(Vector2(sx - 12 * PX, y), Vector2(24, 24) * PX), false)
			Kit.text(self, Vector2(sx, y + 26 * PX), stats[i][1], Kit.TEXT, 2, HORIZONTAL_ALIGNMENT_CENTER)
		if not multiplayer.is_server(): Kit.text(self, Vector2(cx, panel.end.y - 34 * PX), "esperando al anfitrión", Kit.DIM, 1, HORIZONTAL_ALIGNMENT_CENTER)
	elif run.phase == "upgrade" and _choices.is_empty():
		Kit.text(self, size * 0.5, "esperando a la cuadrilla…", Kit.DIM, 1, HORIZONTAL_ALIGNMENT_CENTER)
	elif run.phase == "upgrade" and _picking == "":
		var label: String = "NIVEL %d" % run.level
		Kit.tape(self, Vector2(size.x * 0.5 - (Kit.width(label) + 8 * PX) * 0.5, _cards_top() - 30 * PX), label, "tool")
	elif run.phase == "paused" or _picking != "":
		var area := _workshop_rect()
		Kit.panel(self, area, "tool", "TALLER" if _picking == "" else "COLOCA: %s" % Build.PIECES[_picking]["name"].to_upper())

func _end_rect() -> Rect2:
	var w: float = 220 * PX
	var h: float = 110 * PX
	return Rect2(Vector2(roundf((size.x - w) * 0.5 / PX) * PX, roundf((size.y - h) * 0.42 / PX) * PX), Vector2(w, h))

func _workshop_rect() -> Rect2:
	return Rect2(Vector2(10, 14) * PX, size - Vector2(20, 24) * PX)

func _cards_top() -> float:
	return roundf((size.y - CARD.y) * 0.46 / PX) * PX

func _rebuild() -> void:
	_hotkeys.clear()
	_editor = null
	for child: Node in _controls.get_children():
		_controls.remove_child(child)
		child.queue_free()
	match run.phase:
		"upgrade":
			if _choices.is_empty(): pass
			elif _picking == "": _build_offers()
			else: _build_placement()
		"paused":
			_build_workshop()
		"won", "lost":
			var panel := _end_rect()
			var row: float = panel.end.y - 22 * PX
			var w: float = 90 * PX
			if multiplayer.is_server():
				_button(Rect2(Vector2(panel.get_center().x - w - 4 * PX, row), Vector2(w, 15 * PX)), func() -> void: run.restart.rpc_id(1), "Otro turno").grab_focus()
				_button(Rect2(Vector2(panel.get_center().x + 4 * PX, row), Vector2(w, 15 * PX)), _to_menu, "Menú")
			else:
				_button(Rect2(Vector2(panel.get_center().x - w * 0.5, row), Vector2(w, 15 * PX)), _to_menu, "Menú").grab_focus()

func _button(rect: Rect2, callback: Callable, label: String) -> Button:
	var button := Button.new()
	button.text = label
	button.position = rect.position
	button.size = rect.size
	button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	button.pressed.connect(callback)
	_controls.add_child(button)
	return button

func _to_menu() -> void:
	get_tree().paused = false
	Lobby.instance.go_to_menu()

func _build_offers() -> void:
	var gap: float = 14 * PX
	var left: float = roundf((size.x - (CARD.x * _choices.size() + gap * (_choices.size() - 1))) * 0.5 / PX) * PX
	for i: int in _choices.size():
		var key: String = _choices[i]
		var card := OfferCard.new()
		card.key = key
		card.number = i + 1
		card.level = int(my_build()["tools"].get(key, 0)) if Build.is_tool_key(key) else 0
		card.position = Vector2(left + i * (CARD.x + gap), _cards_top())
		card.size = CARD
		var choose := func() -> void:
			if Build.is_tool_key(key): run.choose_upgrade.rpc_id(1, key, -1)
			else: _picking = key
		card.pressed.connect(choose)
		_hotkeys.append(choose)
		_controls.add_child(card)
		if i == 0: card.grab_focus()

func _open_editor(new_piece: String = "") -> Control:
	var area := _workshop_rect()
	var editor: Control = NodeEditor.new()
	editor.position = area.position + Vector2(10, 14) * PX
	editor.size = area.size - Vector2(20, 40) * PX
	_controls.add_child(editor)
	editor.weapon = "water" if run.local_player() is Support else "fire"
	editor.setup(my_build(), new_piece)
	_editor = editor
	return editor

## Level-up: the chosen piece arrives in the box; the player may rearrange anything around it.
## Nothing reaches the host until «Listo».
func _build_placement() -> void:
	var editor: Control = _open_editor(_picking)
	var area := _workshop_rect()
	var row: float = area.end.y - 21 * PX
	_button(Rect2(Vector2(area.end.x - 168 * PX, row), Vector2(80, 15) * PX), func() -> void: run.choose_upgrade.rpc_id(1, _picking, -1, editor.draft), "Listo").grab_focus()
	_button(Rect2(Vector2(area.end.x - 84 * PX, row), Vector2(76, 15) * PX), func() -> void: _picking = "", "Otra pieza")

## The workshop in the pause: every change goes to the host at once, which checks it against the
## pieces owned.
func _build_workshop() -> void:
	var editor: Control = _open_editor()
	editor.changed.connect(func(build: Dictionary) -> void: run.submit_build.rpc_id(1, build))
	var area := _workshop_rect()
	var row: float = area.end.y - 21 * PX
	if multiplayer.is_server(): _button(Rect2(Vector2(area.end.x - 168 * PX, row), Vector2(80, 15) * PX), func() -> void: run.toggle_pause.rpc_id(1), "Reanudar").grab_focus()
	_button(Rect2(Vector2(area.end.x - 84 * PX, row), Vector2(76, 15) * PX), _to_menu, "Menú")

func _unhandled_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo: return
	if event.keycode == KEY_ESCAPE:
		if _editor != null and _editor.cancel(): pass
		elif _picking != "": _picking = ""
		else: run.toggle_pause.rpc_id(1)
		get_viewport().set_input_as_handled()
	elif run.phase in ["upgrade", "paused"] and event.keycode >= KEY_1 and event.keycode <= KEY_9:
		var index: int = event.keycode - KEY_1
		if index < _hotkeys.size(): _hotkeys[index].call()
		get_viewport().set_input_as_handled()

## A level-up offer: the category on tape, the glyph big in its socket, the name and a few words.
class OfferCard extends Button:
	var key: String = ""
	var number: int = 1
	var level: int = 0
	func _ready() -> void:
		flat = true
		focus_mode = Control.FOCUS_ALL
		for state: String in ["normal", "hover", "pressed", "focus", "hover_pressed", "disabled"]:
			add_theme_stylebox_override(state, StyleBoxEmpty.new())
		mouse_entered.connect(queue_redraw)
		mouse_exited.connect(queue_redraw)
		focus_entered.connect(queue_redraw)
		focus_exited.connect(queue_redraw)
	func _draw() -> void:
		var px: float = Kit.PX
		var accent: String = Kit.accent_of(key)
		var r: Array = Kit.ramp(accent)
		var hot: bool = is_hovered() or has_focus()
		var lift: float = -5 * px if hot else 0.0
		var box := Rect2(Vector2(0, lift), size)
		if hot: Kit.notched(self, box.grow(3 * px), Color(0, 0, 0, 0), r[1], 5)
		var tool: bool = Build.is_tool_key(key)
		var kind: String = ("MEJORA %d" % (level + 1) if level > 0 else "MEJORA") if tool else Build.SLOT_NAMES[Build.slot_of(key)]
		Kit.panel(self, box, accent, kind)
		var socket := Rect2(Vector2(size.x * 0.5 - 22 * px, box.position.y + 14 * px), Vector2(44, 44) * px)
		Kit.notched(self, socket, Kit.BOARD, r[0], 4)
		draw_texture_rect(Kit.icon(key, accent), Rect2(socket.position + Vector2(4, 4) * px, Vector2(36, 36) * px), false)
		var name: String = Build.info(key)["name"]
		Kit.text(self, Vector2(size.x * 0.5, socket.end.y + 4 * px), name.to_upper() if tool else name, r[2], 1, HORIZONTAL_ALIGNMENT_CENTER)
		Kit.text(self, Vector2(size.x * 0.5, socket.end.y + 18 * px), Build.SHORT.get(key, ""), Kit.TEXT if hot else Kit.DIM, 1, HORIZONTAL_ALIGNMENT_CENTER)
		var label: String = "%d" % number
		Kit.keycap(self, Vector2(size.x * 0.5 - maxf(9.0 * px, Kit.width(label) + 6 * px) * 0.5, box.end.y - 17 * px), label)
