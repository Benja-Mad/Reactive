## The workshop as node chains on a dark board. The top row is the basic attack: the operator's
## own weapon with DO pieces plugged into it (attack.gd). Each routine below is one row read left
## to right: WHEN fires it, a draught is drawn, every DO step transforms it in order and THEN arms
## what is left. Under every DO chip its properties show as pixel marks; below the rows the routine under
## the mouse plays out on a small screen, with a few lines of numbers beside it, from the same
## table the host runs. Pieces are dragged from the box onto a slot, or clicked and then clicked
## again where they go; right click (or dragging back to the box) takes a piece out. The host
## validates every change.
extends Control
const Kit = preload("res://scripts/ui/kit.gd")
const Build = preload("res://scripts/survivor/build.gd")
const Recipe = preload("res://scripts/survivor/recipe.gd")
const Rules = preload("res://scripts/survivor/rules.gd")
const Attack = preload("res://scripts/survivor/attack.gd")
const PX: float = Kit.PX
const ACCENT := {"when": "when", "step": "do", "then": "then", "water": "do", "weapon": "tool"}
## The attack row's address in `where`, and the weapon's glyph.
const ATTACK := Build.ATTACK
const WEAPON_ICON := {"fire": "fuego", "water": "agua"}
const WEAPON_ACCENT := {"fire": "when", "water": "do"}
const NODE_H: float = 14 * PX
const WIRE: float = 8 * PX
const ROW_H: float = 40 * PX
const BOX_W: float = 100 * PX
const SOCKET: float = 14 * PX
const ROWS_LEFT: float = BOX_W + 16 * PX
## The preview screen: the board's dark, 1 px neon, machines in the hazard rose.
const SCREEN_W: float = 240 * PX
const GLASS := Color("070a10")
const GRID := Color("161d2b")
const NEON := {"water": Color("36c8e0"), "ice": Color("93f3ff"), "steam": Color("c8d0dc"), "fire": Color("ff8a3a"), "current": Color("f4e46a"), "scrap": Color("b08a6a")}
## The source node: the glyph and the word under it for where a routine draws from.
const SOURCE_ICON := {"water": "agua", "fire": "fuego", "current": "arco", "scrap": "chatarra"}
const SOURCE_ACCENT := {"water": "", "fire": "when", "current": "tool", "scrap": "mute"}
const SOURCE_TAG := {"water": "charco", "fire": "tambor", "current": "trafo", "scrap": "montón"}
const MACHINE := Color("ff3b6b")
const OPERATOR := Color("ffad4a")
const GRAVITY := Color("7a66e8")
const BRASS := Color("ffd27a")
const BLAST := Color("fff0c8")
const SCALD := Color("ff8a3a")
const SPARK := Color("f0ecff")
const WARN := Color("e0a040")
const LINK := Color("b4a6ff")
const HOT_RING := Color("ff6a24")
const LOOP: float = 5.2
const PX_PER_M: float = 3.0 * Kit.PX
signal changed(build: Dictionary)
var draft: Dictionary = {}
## The level-up piece: it starts first in the box, marked as new, until it is moved.
var incoming: String = ""
var _fresh: bool = false
var _nodes: Array[Dictionary] = []
var _targets: Array[Dictionary] = []
var _headers: Array[Dictionary] = []
var _box_area := Rect2()
var _held: Dictionary = {}
var _pressed: Dictionary = {}
var _press_at := Vector2.ZERO
var _dragging: bool = false
var _mouse := Vector2.ZERO
## The routine the panel reads out: the row last under the mouse (ATTACK for the attack).
var focus: int = 0
## Whose weapon the attack row plugs into: "fire" for Brasa, "water" for the Sereno.
var weapon: String = "fire"
var _time: float = 0.0
var _reaction_button := Rect2()

func setup(build: Dictionary, new_piece: String = "") -> void:
	draft = build.duplicate(true)
	incoming = new_piece
	_fresh = new_piece != ""
	if _fresh: draft["box"].insert(0, new_piece)
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	for index: int in draft["routines"].size():
		if draft["routines"][index]["when"] != "":
			focus = index
			break
	if not draft.has("attack"): draft["attack"] = {"steps": []}
	_layout()

## Esc while a piece is in hand puts it back; returns whether there was one.
func cancel() -> bool:
	if _held.is_empty(): return false
	_held = {}
	_dragging = false
	_layout()
	return true

func _process(delta: float) -> void:
	_time += delta
	queue_redraw()

# --- Layout ---------------------------------------------------------------------------------

static func _label_of(key: String) -> String:
	return Build.PIECES[key]["name"]

func _node_width(key: String, placeholder: String) -> float:
	if key == "": return 20 * PX if placeholder != "" else SOCKET
	return Kit.width(_label_of(key)) + 22 * PX

func _panel_top() -> float:
	return (draft["routines"].size() + 1) * ROW_H + 8 * PX

## Where a row's nodes sit: the attack first, then the routines in order.
static func _row_top(ri: int) -> float:
	return (0 if ri == ATTACK else ri + 1) * ROW_H + 4 * PX

## The row under a height on the board, or -1 for none.
func _row_at(y: float) -> int:
	if y < 0: return -1
	var row: int = int(y / ROW_H)
	if row == 0: return ATTACK
	return row - 1 if row - 1 < draft["routines"].size() else -1

## Recomputes every node and every drop slot. Slots exist only for the slot type in hand, and only
## where the piece would actually fit.
func _layout() -> void:
	_nodes.clear()
	_targets.clear()
	_headers.clear()
	_box_area = Rect2(0, 0, BOX_W, size.y)
	# The box, grouped by what each piece is: glyphs only, the name shows under the mouse.
	var y: float = 0.0
	for slot: String in ["when", "step", "then"]:
		var keys: Array[int] = []
		for index: int in draft["box"].size():
			if Build.PIECES[draft["box"][index]]["slot"] == slot: keys.append(index)
		_headers.append({"at": Vector2(0, y), "slot": slot})
		y += 16 * PX
		for n: int in keys.size():
			var index: int = keys[n]
			var at := Vector2((n % 6) * 16 * PX, y + (n / 6) * 16 * PX)
			_nodes.append({"rect": Rect2(at, Vector2(SOCKET, SOCKET)), "key": draft["box"][index], "slot": slot, "where": {"routine": -1, "index": index}, "fresh": _fresh and index == 0, "chip": true})
		y += ceili(keys.size() / 6.0) * 16 * PX + 6 * PX
	var held_slot: String = _held.get("slot", "")
	var lifted: Dictionary = Build.take(draft, _held["where"])[0] if not _held.is_empty() else draft
	if not _held.is_empty() and int(_held["where"]["routine"]) != -1:
		_targets.append({"rect": _box_area, "where": {"routine": -1}, "box": true})
	_layout_attack(held_slot, lifted)
	for ri: int in draft["routines"].size():
		var routine: Dictionary = draft["routines"][ri]
		var top: float = _row_top(ri)
		var x: float = ROWS_LEFT + 14 * PX
		var when_rect := Rect2(x, top, _node_width(routine["when"], "+"), NODE_H)
		_add_node_or_slot(when_rect, routine["when"], "when", {"routine": ri, "slot": "when"}, held_slot, lifted)
		x = when_rect.end.x + WIRE
		var water_w: float = Kit.width(Recipe.FROM[routine.get("from", "water")]) + 22 * PX
		_nodes.append({"rect": Rect2(x, top, water_w, NODE_H), "key": "", "slot": "water", "where": {"routine": ri, "slot": "water"}})
		x += water_w + WIRE
		for step: int in routine["steps"].size():
			if held_slot == "step": _try_slot(Rect2(x - WIRE * 0.5 - 4 * PX, top + NODE_H * 0.5 - 4 * PX, 8 * PX, 8 * PX), {"routine": ri, "slot": "step", "index": step}, lifted, true)
			var key: String = routine["steps"][step]
			var rect := Rect2(x, top, _node_width(key, ""), NODE_H)
			_nodes.append({"rect": rect, "key": key, "slot": "step", "where": {"routine": ri, "slot": "step", "index": step}})
			x = rect.end.x + WIRE
		if routine["steps"].size() < Build.MAX_STEPS or (held_slot == "step" and int(_held["where"].get("routine", -1)) == ri):
			var rect := Rect2(x, top, _node_width("", "+"), NODE_H)
			_nodes.append({"rect": rect, "key": "", "slot": "step", "where": {"routine": ri, "slot": "step", "index": routine["steps"].size()}, "placeholder": "+"})
			if held_slot == "step": _try_slot(rect, {"routine": ri, "slot": "step", "index": routine["steps"].size()}, lifted)
			x = rect.end.x + WIRE
		var then_rect := Rect2(x, top, _node_width(routine["then"], "+"), NODE_H)
		_add_node_or_slot(then_rect, routine["then"], "then", {"routine": ri, "slot": "then"}, held_slot, lifted)
	queue_redraw()

## The attack row: the weapon, then its DO pieces with slots between them, up to Attack.MAX_STEPS.
func _layout_attack(held_slot: String, lifted: Dictionary) -> void:
	var top: float = _row_top(ATTACK)
	var x: float = ROWS_LEFT + 14 * PX
	var weapon_w: float = Kit.width(Attack.WEAPON[weapon]["name"]) + 22 * PX
	_nodes.append({"rect": Rect2(x, top, weapon_w, NODE_H), "key": "", "slot": "weapon", "where": {"routine": ATTACK, "slot": "weapon"}})
	x += weapon_w + WIRE
	var steps: Array = Build.attack_steps(draft)
	for step: int in steps.size():
		if held_slot == "step": _try_slot(Rect2(x - WIRE * 0.5 - 4 * PX, top + NODE_H * 0.5 - 4 * PX, 8 * PX, 8 * PX), {"routine": ATTACK, "slot": "step", "index": step}, lifted, true)
		var rect := Rect2(x, top, _node_width(steps[step], ""), NODE_H)
		_nodes.append({"rect": rect, "key": steps[step], "slot": "step", "where": {"routine": ATTACK, "slot": "step", "index": step}})
		x = rect.end.x + WIRE
	if steps.size() < Attack.MAX_STEPS or (held_slot == "step" and int(_held["where"].get("routine", -1)) == ATTACK):
		var rect := Rect2(x, top, _node_width("", "+"), NODE_H)
		_nodes.append({"rect": rect, "key": "", "slot": "step", "where": {"routine": ATTACK, "slot": "step", "index": steps.size()}, "placeholder": "+"})
		if held_slot == "step": _try_slot(rect, {"routine": ATTACK, "slot": "step", "index": steps.size()}, lifted)

func _add_node_or_slot(rect: Rect2, key: String, slot: String, where: Dictionary, held_slot: String, lifted: Dictionary) -> void:
	var node: Dictionary = {"rect": rect, "key": key, "slot": slot, "where": where}
	if key == "": node["placeholder"] = "+"
	_nodes.append(node)
	if held_slot == slot: _try_slot(rect, where, lifted)

func _try_slot(rect: Rect2, where: Dictionary, lifted: Dictionary, between: bool = false) -> void:
	var result: Dictionary = Build.put(lifted, _held["key"], where)
	if not result.is_empty(): _targets.append({"rect": rect, "where": where, "result": result, "between": between})

func _row_node(ri: int, slot: String, index: int = -1) -> Dictionary:
	for node: Dictionary in _nodes:
		var where: Dictionary = node["where"]
		if int(where.get("routine", -2)) == ri and where.get("slot", "") == slot and (index < 0 or int(where.get("index", -1)) == index): return node
	return {}

# --- Input ----------------------------------------------------------------------------------

func _node_at(point: Vector2) -> Dictionary:
	for node: Dictionary in _nodes:
		if node["key"] != "" and (node["rect"] as Rect2).has_point(point): return node
	return {}

func _source_at(point: Vector2) -> Dictionary:
	for node: Dictionary in _nodes:
		if node["slot"] == "water" and (node["rect"] as Rect2).has_point(point): return node
	return {}

func _target_at(point: Vector2) -> Dictionary:
	# Small slots between nodes win over the box area they never overlap anyway.
	for target: Dictionary in _targets:
		if not target.get("box", false) and (target["rect"] as Rect2).grow(4).has_point(point): return target
	for target: Dictionary in _targets:
		if target.get("box", false) and (target["rect"] as Rect2).has_point(point): return target
	return {}

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		_mouse = event.position
		if _mouse.x > ROWS_LEFT and _row_at(_mouse.y) != -1: focus = _row_at(_mouse.y)
		if not _pressed.is_empty() and not _dragging and _mouse.distance_to(_press_at) > 6.0:
			_dragging = true
			_pick(_pressed)
	elif event is InputEventMouseButton:
		var button := event as InputEventMouseButton
		_mouse = button.position
		# Clicking a routine's source node cycles what it draws: water, fire, current, scrap.
		var source: Dictionary = _source_at(_mouse) if button.button_index == MOUSE_BUTTON_LEFT and button.pressed and _held.is_empty() else {}
		if not source.is_empty():
			var next: Dictionary = draft.duplicate(true)
			var routine: Dictionary = next["routines"][int(source["where"]["routine"])]
			routine["from"] = Build.next_source(routine.get("from", "water"))
			focus = int(source["where"]["routine"])
			_commit(next)
			accept_event()
			return
		if button.button_index == MOUSE_BUTTON_LEFT and button.pressed and _held.is_empty() and focus != ATTACK and _reaction_button.has_point(_mouse):
			var next: Dictionary = draft.duplicate(true)
			var routine: Dictionary = next["routines"][focus]
			routine["on"] = Recipe.ON[(Recipe.ON.find(routine.get("on", "contact")) + 1) % Recipe.ON.size()]
			_commit(next)
			accept_event()
			return
		if button.button_index == MOUSE_BUTTON_RIGHT and button.pressed:
			var node: Dictionary = _node_at(_mouse)
			if not node.is_empty() and int(node["where"]["routine"]) != -1:
				var lifted: Array = Build.take(draft, node["where"])
				_commit(Build.put(lifted[0], lifted[1], {"routine": -1}))
			accept_event()
		elif button.button_index == MOUSE_BUTTON_LEFT:
			if button.pressed:
				if not _held.is_empty(): _drop(_mouse)
				else:
					_pressed = _node_at(_mouse)
					_press_at = _mouse
			else:
				if _dragging: _drop(_mouse)
				elif not _pressed.is_empty(): _pick(_pressed)
				_pressed = {}
				_dragging = false
			accept_event()

func _pick(node: Dictionary) -> void:
	_held = {"key": node["key"], "slot": node["slot"], "where": node["where"]}
	_layout()

func _drop(point: Vector2) -> void:
	var target: Dictionary = _target_at(point)
	var held: Dictionary = _held
	_held = {}
	_dragging = false
	if target.is_empty():
		_layout()
		return
	var lifted: Array = Build.take(draft, held["where"])
	if int(target["where"]["routine"]) != -1: focus = int(target["where"]["routine"])
	_commit(Build.put(lifted[0], lifted[1], target["where"]), int(held["where"]["routine"]) == -1 and int(held["where"].get("index", -1)) == 0)

func _commit(next: Dictionary, moved_fresh: bool = false) -> void:
	if next.is_empty():
		_layout()
		return
	if moved_fresh: _fresh = false
	draft = next
	_layout()
	changed.emit(draft)

# --- Drawing: rows --------------------------------------------------------------------------

func _icon(key: String, at: Vector2, accent: String = "") -> void:
	draw_texture_rect(Kit.icon(key, accent), Rect2(at, Vector2(12, 12) * PX), false)

func _draw_node(node: Dictionary, idle: bool, lifted: bool) -> void:
	var rect: Rect2 = node["rect"]
	var slot: String = node["slot"]
	var accent: String = ACCENT[slot]
	if lifted:
		Kit.dashed(self, rect, Kit.ramp(accent)[0])
		return
	if slot == "weapon":
		draw_style_box(Kit.chip_box("when" if weapon == "fire" else "do"), rect)
		_icon(WEAPON_ICON[weapon], rect.position + Vector2(2, 1) * PX, WEAPON_ACCENT[weapon])
		Kit.text(self, rect.position + Vector2(16 * PX, 0), Attack.WEAPON[weapon]["name"], NEON[weapon])
		return
	if slot == "water":
		var from: String = draft["routines"][int(node["where"]["routine"])].get("from", "water")
		var hover: bool = _held.is_empty() and rect.has_point(_mouse)
		draw_style_box(Kit.chip_box("do", "" if hover else "dim"), rect)
		_icon(SOURCE_ICON[from], rect.position + Vector2(2, 1) * PX, SOURCE_ACCENT[from])
		Kit.text(self, rect.position + Vector2(16 * PX, 0), Recipe.FROM[from], NEON[from] if hover else Kit.DIM)
		return
	if node["key"] == "":
		Kit.dashed(self, rect, Kit.ramp(accent)[0])
		Kit.text(self, rect.position + Vector2(rect.size.x * 0.5, 0), node.get("placeholder", ""), Kit.ramp(accent)[0], 1, HORIZONTAL_ALIGNMENT_CENTER)
		return
	if node.get("chip", false):
		var fresh: bool = node.get("fresh", false)
		Kit.notched(self, rect, Kit.FILL_HI if fresh else Kit.FILL, (Kit.RAMPS["tool"][2] if fmod(_time, 0.8) < 0.5 else Kit.RAMPS["tool"][0]) if fresh else Kit.INK)
		_icon(node["key"], rect.position + Vector2(PX, PX))
		return
	draw_style_box(Kit.chip_box(accent, "dim" if idle else ""), rect)
	_icon(node["key"], rect.position + Vector2(2, 1) * PX, "mute" if idle else "")
	Kit.text(self, rect.position + Vector2(16 * PX, 0), _label_of(node["key"]), Kit.DIM if idle else Kit.ramp(accent)[2])
	if idle:
		for x: float in range(int(rect.position.x), int(rect.end.x), int(3 * PX)): draw_rect(Rect2(x, rect.end.y + PX, 2 * PX, PX), WARN)

func _wire(from: Vector2, to: Vector2, live: bool, accent: String, pulse: bool) -> void:
	var color: Color = Kit.ramp(accent)[0] if live else Kit.LINE
	draw_rect(Rect2(from.x, from.y - PX * 0.5, to.x - from.x, PX), color)
	if pulse:
		var p: float = from.x + fposmod(_time * 40.0 * PX, maxf(PX, to.x - from.x))
		draw_rect(Rect2(roundf(p / PX) * PX, from.y - PX * 0.5, PX * 2, PX), Kit.ramp(accent)[3])

## A conduit between rows, routed through the gap under the source row, marked with its glyph.
func _cable(from: Rect2, to: Rect2, key: String, down: bool) -> void:
	var start := Vector2(from.get_center().x if key == "cadena" else from.end.x - 6 * PX, from.end.y if down else from.position.y)
	var finish := Vector2(to.get_center().x, to.position.y if down else to.end.y)
	var lane: float = (from.position.y + ROW_H - 8 * PX) if down else (from.position.y - 3 * PX)
	var points: Array[Vector2] = [start, Vector2(start.x, lane), Vector2(finish.x, lane), finish]
	for i: int in 3:
		var a: Vector2 = points[i]
		var b: Vector2 = points[i + 1]
		var length: float = a.distance_to(b)
		var dir: Vector2 = (b - a).normalized() if length > 0 else Vector2.ZERO
		var t: float = 0.0
		while t < length:
			draw_rect(Rect2((a + dir * t).snapped(Vector2(PX, PX)), Vector2(PX, PX)), LINK)
			t += 3 * PX
	var mid := Vector2(minf(start.x, finish.x) + absf(finish.x - start.x) * 0.5 - 6 * PX, lane - 4 * PX)
	Kit.notched(self, Rect2(mid - Vector2(PX, PX), Vector2(14, 14) * PX), Kit.BOARD, Kit.INK)
	_icon(key, mid)

func _draw() -> void:
	# The board behind the rows: dark, dotted every 8 UI pixels.
	var board := Rect2(ROWS_LEFT, 0, size.x - ROWS_LEFT, _panel_top() - 4 * PX)
	draw_rect(board, Kit.BOARD)
	for gy: float in range(int(board.position.y + 4 * PX), int(board.end.y), int(8 * PX)):
		for gx: float in range(int(board.position.x + 4 * PX), int(board.end.x), int(8 * PX)):
			draw_rect(Rect2(gx, gy, PX, PX), GRID)
	for header: Dictionary in _headers:
		Kit.tape(self, header["at"] + Vector2(PX, 2 * PX), Build.SLOT_NAMES[header["slot"]], ACCENT[header["slot"]], true)
	var held_where: Dictionary = _held.get("where", {})
	var rows: Array = draft["routines"]
	_draw_attack_row(board, held_where)
	for ri: int in rows.size():
		var routine: Dictionary = rows[ri]
		var top: float = _row_top(ri)
		if ri == focus:
			draw_rect(Rect2(ROWS_LEFT, top - 4 * PX, board.size.x, ROW_H), Color("111725"))
			draw_rect(Rect2(ROWS_LEFT, top - 4 * PX, PX, ROW_H), Kit.RAMPS["do"][1])
		Kit.text(self, Vector2(ROWS_LEFT + 5 * PX, top), "%d" % (ri + 1), Kit.TEXT if ri == focus else Kit.FAINT)
		var result: Dictionary = Recipe.simulate(routine["steps"], routine.get("from", "water"))
		var chain: Array[Dictionary] = []
		for node: Dictionary in _nodes:
			if int(node["where"].get("routine", -2)) == ri: chain.append(node)
		var live: bool = routine["when"] != ""
		for i: int in chain.size():
			var node: Dictionary = chain[i]
			var rect: Rect2 = node["rect"]
			var is_step: bool = node["slot"] == "step" and node["key"] != ""
			var step_index: int = int(node["where"].get("index", -1)) if is_step else -1
			var idle: bool = is_step and step_index in result["idle"]
			if i > 0:
				var before: Rect2 = chain[i - 1]["rect"]
				_wire(Vector2(before.end.x, top + NODE_H * 0.5), Vector2(rect.position.x, top + NODE_H * 0.5), live, ACCENT[node["slot"]], live and ri == focus)
			_draw_node(node, idle, node["where"] == held_where and not held_where.is_empty())
			# What comes out of this node, as marks; the word only on the row being read.
			var after: Dictionary = {}
			var tag: String = ""
			if node["slot"] == "water":
				after = Recipe.source(routine.get("from", "water"))
				tag = SOURCE_TAG[routine.get("from", "water")]
			elif is_step:
				after = result["trace"][step_index]["state"]
				tag = result["trace"][step_index]["tag"]
			if not after.is_empty() and not idle:
				var px_end: float = _props(Vector2(rect.position.x + PX, rect.end.y + 3 * PX), after)
				if ri == focus and Kit.width(tag) <= rect.end.x + WIRE * 0.5 - px_end - PX: Kit.text(self, Vector2(px_end + PX, rect.end.y), tag, Kit.DIM)
		var issue: String = Build.problem(routine, rows, ri)
		if issue != "" and routine["when"] != "" and not chain.is_empty():
			Kit.text(self, Vector2((chain[-1]["rect"] as Rect2).end.x + 5 * PX, top), "!", Kit.RAMPS["danger"][1])
	_draw_cables(rows)
	for node: Dictionary in _nodes:
		if int(node["where"].get("routine", 0)) == -1: _draw_node(node, false, node["where"] == held_where)
	# Slots that accept the piece in hand.
	var hovered: Dictionary = _target_at(_mouse) if not _held.is_empty() else {}
	for target: Dictionary in _targets:
		var rect: Rect2 = target["rect"]
		var hot: bool = target == hovered
		var amber: Array = Kit.RAMPS["tool"]
		if target.get("box", false):
			if hot: Kit.dashed(self, rect.grow(-PX), amber[1])
			continue
		if target.get("between", false):
			var c: Vector2 = rect.get_center().snapped(Vector2(PX, PX))
			var r: float = (4 if hot else 3) * PX
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -r), c + Vector2(r, 0), c + Vector2(0, r), c + Vector2(-r, 0)]), amber[2] if hot else amber[0])
		else:
			if hot: Kit.notched(self, rect.grow(PX), Color(amber[0], 0.6), Color(0, 0, 0, 0))
			Kit.dashed(self, rect.grow(PX), amber[2] if hot else amber[1])
	var shown: Dictionary = draft
	var index: int = focus if focus == ATTACK else clampi(focus, 0, rows.size() - 1)
	if hovered.has("result"):
		shown = hovered["result"]
		index = int(hovered["where"]["routine"])
	_draw_panel(shown, index, hovered.has("result"))
	if not _held.is_empty():
		var key: String = _held["key"]
		# Carried below-right of the pointer, so the slot under it stays visible.
		var rect := Rect2((_mouse + Vector2(7, 6) * PX).snapped(Vector2(PX, PX)), Vector2(_node_width(key, ""), NODE_H))
		_draw_node({"rect": rect, "key": key, "slot": _held["slot"], "where": {}}, false, false)
	else:
		_draw_tooltip()

## The attack row: the weapon and its pieces on one wire, always live; pieces that add nothing are
## marked like an idle DO step.
func _draw_attack_row(board: Rect2, held_where: Dictionary) -> void:
	var top: float = _row_top(ATTACK)
	var mine: Color = Kit.ramp("when" if weapon == "fire" else "do")[1]
	if focus == ATTACK:
		draw_rect(Rect2(ROWS_LEFT, top - 4 * PX, board.size.x, ROW_H), Color("111725"))
		draw_rect(Rect2(ROWS_LEFT, top - 4 * PX, PX, ROW_H), mine)
	Kit.text(self, Vector2(ROWS_LEFT + 5 * PX, top), "A", Kit.TEXT if focus == ATTACK else Kit.FAINT)
	# A rule under the attack row: the routines below run on their own, the attack is the weapon.
	draw_rect(Rect2(ROWS_LEFT, top + ROW_H - 6 * PX, board.size.x, PX), Kit.LINE)
	var hit: Dictionary = Attack.profile(Build.attack_steps(draft), weapon)
	var chain: Array[Dictionary] = []
	for node: Dictionary in _nodes:
		if int(node["where"].get("routine", -9)) == ATTACK: chain.append(node)
	for i: int in chain.size():
		var node: Dictionary = chain[i]
		var rect: Rect2 = node["rect"]
		var is_step: bool = node["slot"] == "step" and node["key"] != ""
		var idle: bool = is_step and hit["trace"][int(node["where"]["index"])]["idle"]
		if i > 0:
			var before: Rect2 = chain[i - 1]["rect"]
			_wire(Vector2(before.end.x, top + NODE_H * 0.5), Vector2(rect.position.x, top + NODE_H * 0.5), true, ACCENT[node["slot"]] if node["slot"] != "weapon" else "do", focus == ATTACK)
		_draw_node(node, idle, node["where"] == held_where and not held_where.is_empty())

func _draw_cables(rows: Array) -> void:
	for ri: int in rows.size():
		var routine: Dictionary = rows[ri]
		if routine["then"] == "cadena":
			var target: int = Build.relay_target(rows, ri)
			var from: Dictionary = _row_node(ri, "then")
			var to: Dictionary = _row_node(target, "water") if target >= 0 else {}
			if not from.is_empty() and not to.is_empty(): _cable(from["rect"], to["rect"], "cadena", target > ri)
		if routine["when"] == "eco" and ri > 0:
			var from: Dictionary = _row_node(ri - 1, "water")
			var to: Dictionary = _row_node(ri, "when")
			if not from.is_empty() and not to.is_empty(): _cable(from["rect"], to["rect"], "eco", true)

## The piece under the mouse: its name and a few words, on a small plate by the pointer.
func _draw_tooltip() -> void:
	if _reaction_button.has_point(_mouse):
		var at: Vector2 = _reaction_button.position - Vector2(0, 17 * PX)
		var message: String = "Clic: contacto / rotura / 2 s / pulso"
		Kit.panel(self, Rect2(at, Vector2(Kit.width(message) + 10 * PX, 16 * PX)), "then")
		Kit.text(self, at + Vector2(4 * PX, 0), message, Kit.TEXT)
		return
	var node: Dictionary = _node_at(_mouse)
	if node.is_empty(): return
	var key: String = node["key"]
	var accent: String = ACCENT[node["slot"]]
	var name: String = _label_of(key)
	var short: String = Build.SHORT.get(key, "")
	var where: Dictionary = node["where"]
	if where.get("slot", "") == "step" and int(where.get("routine", -1)) == ATTACK:
		short = Attack.profile(Build.attack_steps(draft), weapon)["trace"][where["index"]]["text"]
	elif where.get("slot", "") == "step" and int(where.get("routine", -1)) >= 0:
		var trace: Array = Recipe.simulate(draft["routines"][where["routine"]]["steps"], draft["routines"][where["routine"]].get("from", "water"))["trace"]
		short = trace[where["index"]]["text"]
	var w: float = maxf(Kit.width(name) + 18 * PX, Kit.width(short) + 10 * PX)
	var at := (_mouse + Vector2(8, 10) * PX).snapped(Vector2(PX, PX))
	at.x = minf(at.x, size.x - w)
	var rect := Rect2(at, Vector2(w, 26 * PX))
	Kit.notched(self, rect, Kit.FILL_HI, Kit.ramp(accent)[1])
	_icon(key, at + Vector2(3, 1) * PX)
	Kit.text(self, at + Vector2(16 * PX, 0), name, Kit.ramp(accent)[2])
	Kit.text(self, at + Vector2(5 * PX, 12 * PX), short, Kit.TEXT)

# --- Drawing: the panel ---------------------------------------------------------------------

## The routine read out: a looping preview on the left, a few lines of glyphs and numbers on the
## right.
func _draw_panel(build: Dictionary, index: int, proposed: bool) -> void:
	_reaction_button = Rect2()
	var top: float = _panel_top() + 6 * PX
	var height: float = clampf(size.y - top, 70.0 * PX, 170.0 * PX)
	var frame := Rect2(ROWS_LEFT, top, size.x - ROWS_LEFT, height)
	Kit.panel(self, frame, "tool" if proposed else "do")
	var screen := Rect2(frame.position + Vector2(4, 4) * PX, Vector2(minf(SCREEN_W, frame.size.x * 0.5), height - 8 * PX))
	if index == ATTACK:
		_draw_attack_panel(build, frame, screen, proposed)
		return
	_draw_screen(screen, build, index)
	# The title goes on last so the screen does not cover the bottom of its tape.
	Kit.tape(self, frame.position + Vector2(12, -6) * PX, ("RUTINA %d" % (index + 1)) + (" ?" if proposed else ""), "tool" if proposed else "do")
	var x: float = screen.end.x + 10 * PX
	var y: float = frame.position.y + 8 * PX
	var routine: Dictionary = build["routines"][index]
	var line: float = 14 * PX
	if routine["when"] == "":
		Kit.text(self, Vector2(x, y), "sin WHEN", Kit.RAMPS["danger"][2])
		return
	var result: Dictionary = Recipe.simulate(routine["steps"], routine.get("from", "water"))
	var state: Dictionary = result["state"]
	# WHEN and its recharge.
	_icon(routine["when"], Vector2(x, y))
	Kit.text(self, Vector2(x + 15 * PX, y - PX), _label_of(routine["when"]), Kit.RAMPS["when"][2])
	if routine["when"] != "eco":
		var cx: float = x + 15 * PX + Kit.width(_label_of(routine["when"])) + 10 * PX
		_icon("cada", Vector2(cx, y), "mute")
		Kit.text(self, Vector2(cx + 15 * PX, y - PX), "%s s" % Recipe._num(snappedf(Build.cooldown(build, index), 0.1)), Kit.TEXT)
	y += line
	# What is left: marks and the matter's two words.
	var end: float = _props(Vector2(x + PX, y + 3 * PX), state)
	Kit.text(self, Vector2(maxf(end + 3 * PX, x + 15 * PX), y - PX), Recipe.matter_text(state), Kit.TEXT)
	y += line
	# What it does to what it touches, first clause of each.
	for touch: String in Rules.touch(state):
		Kit.text(self, Vector2(x + 15 * PX, y - PX), touch.get_slice(",", 0), Kit.DIM)
		_icon("arco" if state["charge"] > 0 else "frio" if state["temp"] < 0 else "fuego", Vector2(x, y), "mute")
		y += line
	if routine["then"] != "":
		_reaction_button = Rect2(x, y, maxf(100, frame.end.x - x - 4 * PX), line)
		Kit.dashed(self, _reaction_button, Kit.RAMPS["then"][1])
		_icon(routine["then"], Vector2(x, y))
		Kit.text(self, Vector2(x + 15 * PX, y - PX), "%s · %s · clic" % [_label_of(routine["then"]), Recipe.moment(state, routine["then"], routine.get("on", "contact")).get_slice(" (", 0)], Kit.RAMPS["then"][2])
		y += line
	if routine["then"] == "cadena":
		var target: int = Build.relay_target(build["routines"], index)
		_icon("cadena", Vector2(x, y), "mute")
		Kit.text(self, Vector2(x + 15 * PX, y - PX), ("→ rutina %d" % (target + 1)) if target >= 0 else "→ nada", Kit.DIM)
		y += line
	var issue: String = Build.problem(routine, build["routines"], index)
	if issue != "" and y < frame.end.y - line:
		Kit.text(self, Vector2(x, y - PX), "! " + issue.trim_suffix("."), Kit.RAMPS["danger"][2])

## The attack read out: what one hit does on a loop on the left, its numbers and each piece's line
## on the right, from attack.gd -- the same profile the host strikes with.
func _draw_attack_panel(build: Dictionary, frame: Rect2, screen: Rect2, proposed: bool) -> void:
	var steps: Array = Build.attack_steps(build)
	var hit: Dictionary = Attack.profile(steps, weapon)
	_draw_attack_screen(screen, hit)
	Kit.tape(self, frame.position + Vector2(12, -6) * PX, "ATAQUE" + (" ?" if proposed else ""), "tool" if proposed else "do")
	var x: float = screen.end.x + 10 * PX
	var y: float = frame.position.y + 8 * PX
	var line: float = 14 * PX
	var room: float = frame.end.x - x - 4 * PX
	var fit := func(value: String) -> String:
		while Kit.width(value) > room and value.length() > 3: value = value.left(value.length() - 4) + "…"
		return value
	var tools: Dictionary = build.get("tools", {})
	var stats: Dictionary = Attack.WEAPON[weapon]
	var damage: float = float(stats["damage"]) + int(tools.get("power", 0)) * float(stats["power"])
	var every: float = float(stats["every"]) * pow(0.82, int(tools.get("cadence", 0)))
	_icon(WEAPON_ICON[weapon], Vector2(x, y), WEAPON_ACCENT[weapon])
	Kit.text(self, Vector2(x + 15 * PX, y - PX), "%s · %s de daño cada %s s" % [Attack.WEAPON[weapon]["name"], Recipe._num(snappedf(damage, 0.1)), ("%.2f" % every).replace(".", ",")], NEON[weapon])
	y += line
	Kit.text(self, Vector2(x + 15 * PX, y - PX), fit.call(Attack.WEAPON[weapon]["text"]), Kit.DIM)
	y += line
	if steps.is_empty():
		Kit.text(self, Vector2(x, y - PX), fit.call("sin DO: cada golpe solo hace eso. Arrastra hasta %d aquí." % Attack.MAX_STEPS), Kit.RAMPS["tool"][2])
		return
	for entry: Dictionary in hit["trace"]:
		if y > frame.end.y - line: break
		_icon(entry["key"], Vector2(x, y), "mute" if entry["idle"] else "")
		Kit.text(self, Vector2(x + 15 * PX, y - PX), fit.call(entry["text"]), Kit.DIM if entry["idle"] else Kit.TEXT)
		y += line
	if y <= frame.end.y - line: Kit.text(self, Vector2(x, y - PX), fit.call("lo extra cae en cada máquina una vez cada 0,5 s"), Kit.FAINT)

## One hit after another on a small pack walking in: the weapon's own matter, and what each piece
## adds -- heat or frost rings, a shove, the pack drawn in or thrown wide, a jump of charge,
## nanites, a patch left behind, a blow from above on the one that flies.
func _draw_attack_screen(rect: Rect2, hit: Dictionary) -> void:
	draw_rect(rect, GLASS)
	for gy: float in range(int(rect.position.y + 4 * PX), int(rect.end.y), int(8 * PX)):
		for gx: float in range(int(rect.position.x + 4 * PX), int(rect.end.x), int(8 * PX)):
			draw_rect(Rect2(gx, gy, PX, PX), GRID)
	# Closer in than a routine's screen: a weapon's reach is a few metres, and each hit has to read.
	var m := func(meters: float) -> float: return meters * PX_PER_M * (2.4 if weapon == "fire" else 1.5)
	var mid: float = rect.position.y + rect.size.y * 0.56
	var me := Vector2(rect.position.x + 14 * PX, mid)
	var t: float = fmod(_time, LOOP)
	var fire: bool = weapon == "fire"
	var reach: float = m.call(float(Attack.WEAPON[weapon]["reach"]) + (3.0 if hit["aloft"] and not fire else 0.0))
	var colour: Color = NEON[weapon]
	if hit["temp"] >= 2: colour = SCALD if not fire else NEON["fire"].lightened(0.3)
	elif hit["temp"] < 0: colour = NEON["ice"]
	# The pack walks in; from when the first is in reach, the weapon fires every beat.
	var start: float = rect.end.x - 10
	var lead_x: float = maxf(me.x + reach * 0.75, lerpf(start, me.x + reach * 0.75, clampf(t / 1.0, 0, 1)))
	var offsets: Array[Vector2] = [Vector2(0, 0), Vector2(m.call(1.6), -m.call(1.8)), Vector2(m.call(2.0), m.call(1.6))]
	var firing: bool = t > 1.0 and t < LOOP - 0.5
	var shots: int = int((t - 1.0) / 0.5) + 1 if firing else 0
	var kick: float = 0.0
	var spread: float = 1.0
	if firing:
		kick = minf(shots, 4) * hit["knock"] * 3.0 + (minf(shots, 4) * 4.0 if hit["scatter"] else 0.0)
		if hit["gather"]: spread = maxf(0.35, 1.0 - shots * 0.18)
		if hit["scatter"]: spread = minf(2.2, 1.0 + shots * 0.3)
	var lead := Vector2(lead_x + kick, mid)
	var pack: Array[Vector2] = []
	for offset: Vector2 in offsets: pack.append(lead + offset * spread)
	# A flyer overhead: only a raised weapon reaches it; a dropped blow brings it down.
	var flyer := Vector2(lead_x + 4, mid - 26)
	var downed: bool = hit["slam"] and hit["aloft"] and firing and shots >= 3
	if downed: flyer.y = mid - 4
	var shot_t: float = fmod(t - 1.0, 0.5) if firing else 1.0
	var hot: bool = shot_t < 0.18
	if firing and hot:
		var aim: Vector2 = pack[0]
		if fire:
			for i: int in 5:
				var fan: float = (i - 2) * 0.12
				var tip: Vector2 = me + Vector2.from_angle(fan) * minf(reach, aim.distance_to(me) + 6)
				draw_line(me, tip, colour, PX)
			if hit["aloft"]: draw_line(me, flyer, colour, PX)
		else:
			var p: Vector2 = me.lerp(aim, clampf(shot_t / 0.18, 0, 1))
			draw_circle(p, 2 * PX, colour)
			if hit["aloft"]: draw_circle(me.lerp(flyer, clampf(shot_t / 0.18, 0, 1)), 2 * PX, colour)
	if firing and not hot and not fire and shot_t < 0.4:
		draw_arc(pack[0], m.call(2.0) * clampf((shot_t - 0.18) / 0.2, 0, 1), 0, TAU, 24, colour, PX)
	# Wall: what the weapon leaves on the floor where it struck.
	if hit["trail"] and shots >= 2:
		_matter(Vector2(lead_x + 2, mid), {"material": weapon if weapon == "water" else "fire", "shape": "patch", "scald": false, "hard": false, "coat": 0, "charge": 0, "well": false, "repel": false}, t)
	# The machines, with what the hits left on them.
	var struck: bool = firing and shots >= 1
	for i: int in pack.size():
		var body: Vector2 = pack[i]
		_machine(body, firing and hot and i == 0)
		if not struck: continue
		if hit["temp"] != 0: draw_arc(body, 6 * PX * 0.5 + 2, 0, TAU, 12, HOT_RING if hit["temp"] > 0 else NEON["ice"], PX)
		if weapon == "water" and hit["temp"] <= 0: draw_rect(Rect2(body + Vector2(-3, 6), Vector2(6, PX)), NEON["water"])
		if hit["coat"] > 0:
			for k: int in 3 * hit["coat"]:
				var angle: float = k * TAU / (3 * hit["coat"]) + t * 2.0
				draw_rect(Rect2((body + Vector2(cos(angle), sin(angle)) * 8.0).snapped(Vector2(PX, PX)), Vector2(PX, PX)), BRASS)
	if struck and hit["charge"] > 0 and hot:
		for i: int in mini(hit["charge"], pack.size() - 1): _zap(pack[i], pack[i + 1], t)
	if hit["slam"] and firing and shots % 2 == 1 and hot:
		draw_line(pack[0] + Vector2(0, -30), pack[0], BLAST, PX)
		draw_arc(pack[0], 7, 0, TAU, 16, BLAST, PX)
	if not downed: draw_circle(flyer + Vector2(0, 26), 3, Color(0, 0, 0, 0.6))
	_machine(flyer, firing and hot and hit["aloft"])
	_dot(me, OPERATOR, 4)
	var title: String = Attack.WEAPON[weapon]["name"]
	if not hit["trace"].is_empty() and firing:
		var live: Array = hit["trace"].filter(func(entry: Dictionary) -> bool: return not entry["idle"])
		if not live.is_empty():
			var entry: Dictionary = live[shots % live.size()]
			_icon(entry["key"], rect.position + Vector2(3, 3) * PX)
			title = _label_of(entry["key"])
	Kit.text(self, rect.position + Vector2(18 if firing and not hit["trace"].is_empty() else 4, 2) * PX, title, BLAST)
	draw_rect(Rect2(rect.position, Vector2(roundf(rect.size.x * t / LOOP / PX) * PX, PX)), Kit.RAMPS["when"][1])

## The screen: the operator on the left, a machine coming in from the right, and the routine
## happening between them on a loop. Distances are to scale (3 UI pixels a metre).
func _draw_screen(rect: Rect2, build: Dictionary, index: int) -> void:
	draw_rect(rect, GLASS)
	for gy: float in range(int(rect.position.y + 4 * PX), int(rect.end.y), int(8 * PX)):
		for gx: float in range(int(rect.position.x + 4 * PX), int(rect.end.x), int(8 * PX)):
			draw_rect(Rect2(gx, gy, PX, PX), GRID)
	var routine: Dictionary = build["routines"][index]
	var mid: float = rect.position.y + rect.size.y * 0.56
	var me := Vector2(rect.position.x + 14 * PX, mid)
	var t: float = fmod(_time, LOOP)
	var me_fired: Vector2 = me
	if routine["when"] == "rastro":
		# Walking: the matter is left behind where the operator was when it fired.
		me_fired.x += 1.2 * 18.0
		me.x += minf(t, 1.2) * 18.0
	var title: String = ""
	if routine["when"] == "":
		_dot(me, OPERATOR, 4)
		Kit.text(self, rect.position + Vector2(4, 2) * PX, "WHEN ?", Kit.RAMPS["when"][2])
		return
	var from: String = routine.get("from", "water")
	var result: Dictionary = Recipe.simulate(routine["steps"], from)
	var trace: Array = result["trace"]
	var when: String = routine["when"]
	var m := func(meters: float) -> float: return meters * PX_PER_M
	# Where the machine stands when the routine fires, and where the matter lands.
	var trigger_at := Vector2(me.x + m.call(9.0), mid)
	var place := Vector2(me.x + m.call(3.1), mid)
	var ghost := Vector2.INF
	match when:
		"cada":
			trigger_at = Vector2(me.x + m.call(12.0), mid)
			place = trigger_at
		"rastro":
			place = Vector2(me_fired.x - m.call(1.6), mid)
			trigger_at = Vector2(me.x + m.call(14.0), mid)
		"grupo":
			trigger_at = Vector2(me.x + m.call(11.0), mid)
			place = trigger_at
		"herido":
			trigger_at = Vector2(me.x + m.call(0.9), mid)
			place = Vector2(me.x + m.call(1.8), mid)
		"eco":
			ghost = Vector2(me.x + m.call(3.1), mid)
			place = ghost + Vector2(m.call(2.5), 0)
		"derribo":
			trigger_at = Vector2(me.x + m.call(14.0), mid)
			place = Vector2(me.x + m.call(7.0), mid)
		"charco":
			trigger_at = Vector2(me.x + m.call(8.0), mid)
			place = trigger_at
	var start_x: float = rect.end.x - 10
	# Phase times: approach, build (one beat per step), then the reaction.
	var fired: float = 1.2
	var beat: float = 0.42
	var built: float = fired + 0.35 + trace.size() * beat
	var state: Dictionary = Recipe.source(from)
	var shown_step: int = -1
	if t >= fired + 0.35:
		shown_step = mini(int((t - fired - 0.35) / beat), trace.size() - 1)
		state = trace[shown_step]["state"] if shown_step >= 0 else state
	var final: Dictionary = result["state"]
	# The machine: approaching, then reacting to what the matter does to it.
	var machine := Vector2(lerpf(start_x, trigger_at.x, clampf(t / fired, 0, 1)), mid)
	var blocked_x: float = INF
	if t > fired:
		var walk: float = (t - fired) * m.call(1.9)
		machine.x = trigger_at.x - walk
		if final["shape"] == "wall" and final["material"] in ["ice", "scrap"] and t > built and machine.x < place.x + 7:
			machine.x = place.x + 7
			blocked_x = machine.x
		if (state["well"]) and t > fired + 0.35:
			var pull: Vector2 = place - machine
			machine += pull.limit_length(minf(pull.length() * 0.75, (t - fired) * 26.0))
		if state["repel"] and machine.distance_to(place) < m.call(Recipe.REPEL_RADIUS): machine.x = place.x + m.call(Recipe.REPEL_RADIUS)
		machine.x = maxf(machine.x, me.x + 8)
	# The matter's moment and its THEN.
	var then: String = routine["then"]
	var moment_at: float = built + (Recipe.REACTION_DELAY if routine.get("on", "contact") == "timer" else 0.5)
	if routine.get("on", "contact") == "pulse": moment_at = LOOP + 1.0
	if routine.get("on", "contact") == "broken" and final["material"] not in ["ice", "scrap"]: moment_at = LOOP + 1.0
	var crowd: Array[Vector2] = [machine]
	if when == "grupo":
		# A well draws the group in tight; a repulsor throws it wide.
		var spread: float = 1.6
		if t > fired + 0.35 and state["well"]: spread = maxf(0.35, 1.6 - (t - fired - 0.35) * 0.9)
		if t > fired + 0.35 and state["repel"]: spread = minf(3.2, 1.6 + (t - fired - 0.35) * 2.0)
		crowd = [machine + Vector2(-6, -9) * spread, machine + Vector2(7, 2) * spread, machine + Vector2(-3, 10) * spread]
	# Where the matter comes from: a puddle (drum, transformer, heap) near the operator that runs to
	# the spot when the routine fires and shrinks by what it gave; for «on wade» with water, the
	# puddle the machine walks into.
	var wade: bool = when == "charco" and from == "water"
	var pool: Vector2 = place if wade else Vector2(me_fired.x + m.call(1.2), mid + m.call(4.0))
	var drawn: float = clampf((t - fired) / 0.35, 0.0, 1.0)
	if not wade or t < fired: _pool(pool, 1.0 - drawn * 0.45 if not wade else 1.0, from)
	if not wade and t >= fired and t < fired + 0.35:
		draw_line(pool.lerp(place, maxf(0.0, drawn * 1.6 - 0.6)), pool.lerp(place, minf(1.0, drawn * 1.6)), NEON[from], 2 * PX)
	# WHEN cue.
	if when == "cerca": draw_arc(me, m.call(9.0), -0.6, 0.6, 24, Color(Kit.RAMPS["when"][1], 0.55 if t < fired else 0.2), PX)
	if when == "derribo" and t < fired:
		_cross(place, MACHINE)
	if when == "herido" and t > fired - 0.1 and t < fired + 0.25: draw_circle(me, 9, Color(MACHINE, 0.5))
	if ghost != Vector2.INF:
		draw_rect(Rect2(ghost - Vector2(3, 18), Vector2(6, 36)), Color(BLAST, 0.25), false, PX)
	# The matter, once the routine has fired.
	var gone: bool = false
	var effect_t: float = t - moment_at
	if t >= fired:
		var center: Vector2 = place
		if state["moving"] and shown_step >= 0:
			center.x += minf(t - (fired + 0.35 + trace.size() * beat - beat), 1.4) * m.call(2.2) * (1.0 if when != "rastro" else -1.0)
		if then != "" and effect_t > 0.0 and final["shape"] != "gone":
			gone = then in ["estallar", "colapso"] and final["material"] not in ["ice", "scrap"] and effect_t > 0.6 or then == "fragmentos" and final["material"] in ["water", "fire", "current"] and effect_t > 0.2
		if not gone:
			var drop_step: bool = shown_step >= 0 and trace[shown_step]["key"] == "drop" and t - (fired + 0.35 + shown_step * beat) < beat * 0.7
			var lift: float = 13.0 if state.get("suspended", false) else 0.0
			if state.get("suspended", false): draw_circle(center, 7, Color(0, 0, 0, 0.7))
			if drop_step: lift = (1.0 - (t - (fired + 0.35 + shown_step * beat)) / (beat * 0.7)) * 26.0
			var shard_state: Dictionary = state
			if then != "" and effect_t > 0.0 and final["material"] in ["ice", "scrap"] and then in ["fragmentos", "estallar", "colapso"]:
				shard_state = state.duplicate()
				shard_state["shape"] = "fragments"
			if then == "detonar" and effect_t > 0.0:
				shard_state = shard_state.duplicate()
				shard_state["coat"] = 0
			_matter(center - Vector2(0, lift), shard_state, t)
			# Conduction: a charged matter discharges into the machine that comes within reach.
			var reach: float = m.call(2.4 + (2.8 if final["material"] in ["water", "scrap"] else 0.0) + (5.0 if final["material"] == "current" else 0.0))
			if final["charge"] > 0 and t > built and machine.distance_to(center) < reach and fmod(t, 0.5) < 0.22: _zap(center, machine, t)
			# Ice waits to be broken: the machine hammers it just before the moment.
			if then != "" and routine.get("on", "contact") == "broken" and final["material"] in ["ice", "scrap"] and final["shape"] != "fragments" and effect_t > -0.5 and effect_t < 0.0 and fmod(t, 0.16) < 0.08:
				for i: int in 3: draw_line(center + Vector2(4, -6 + i * 6), center + Vector2(9, -8 + i * 6), BLAST, PX)
			if drop_step: draw_circle(center, 5, Color(0, 0, 0, 0.6))
			if then != "" and t > built: _armed(center, t)
		if then != "" and effect_t > 0.0 and final["shape"] != "gone":
			_effect(then, final, center, machine, rect, effect_t, build, index)
	# The machines, drawn last: hazard rose.
	for body: Vector2 in crowd:
		var flash: bool = then != "" and effect_t > 0.1 and effect_t < 0.45 and body.distance_to(place) < m.call(4.5)
		_machine(body, flash)
	if blocked_x != INF: draw_rect(Rect2(Vector2(blocked_x + 6, mid - 12), Vector2(PX, 24)), MACHINE)
	_dot(me, OPERATOR, 4)
	# What is happening, as the piece's glyph and name.
	var key: String = ""
	if t < fired: key = when
	elif t < built and shown_step >= 0: key = trace[shown_step]["key"]
	elif then != "" and effect_t > -0.5: key = then
	if key != "":
		_icon(key, rect.position + Vector2(3, 3) * PX, "mute" if t < built and shown_step >= 0 and trace[shown_step]["op"] == "" else "")
		title = _label_of(key)
	elif t < built: title = Recipe.FROM[from]
	else: title = Recipe.matter_text(final)
	Kit.text(self, rect.position + Vector2(18 if key != "" else 4, 2) * PX, title, BLAST)
	if shown_step >= 0 and t < built:
		var caption: String = trace[shown_step]["text"]
		while Kit.width(caption) > rect.size.x - 8 * PX and caption.length() > 3: caption = caption.left(caption.length() - 4) + "…"
		Kit.text(self, Vector2(rect.position.x + 4 * PX, rect.end.y - 14 * PX), caption, Kit.TEXT)
	# Time line along the top edge.
	draw_rect(Rect2(rect.position, Vector2(roundf(rect.size.x * t / LOOP / PX) * PX, PX)), Kit.RAMPS["when"][1])

## A puddle seen from above: a flat dark ellipse with its neon rim, `amount` of a full draught.
func _pool(at: Vector2, amount: float, from: String = "water") -> void:
	var half := Vector2(9, 5) * sqrt(maxf(amount, 0.2))
	var points := PackedVector2Array()
	for i: int in 17: points.append(at + Vector2(cos(i * TAU / 16) * half.x, sin(i * TAU / 16) * half.y))
	draw_colored_polygon(points, Color(NEON[from].darkened(0.78), 0.9))
	draw_polyline(points, NEON[from], PX)
	# A drum's flames, a transformer's terminals, a heap's jagged top over the pool they stand in.
	match from:
		"fire":
			for i: int in 3: draw_line(at + Vector2(-4 + i * 4, -2), at + Vector2(-4 + i * 4 + sin(_time * 9.0 + i) * 2.0, -9 - (i % 2) * 3), NEON["fire"], PX)
		"current":
			draw_rect(Rect2(at - Vector2(4, 9), Vector2(8, 8)), GLASS)
			draw_rect(Rect2(at - Vector2(4, 9), Vector2(8, 8)), NEON["current"], false, PX)
			if fmod(_time, 0.6) < 0.2: draw_line(at + Vector2(-3, -10), at + Vector2(3, -13), SPARK, PX)
		"scrap":
			draw_polyline(PackedVector2Array([at + Vector2(-8, 0), at + Vector2(-4, -6), at + Vector2(0, -3), at + Vector2(3, -8), at + Vector2(8, 0)]), NEON["scrap"], PX)

func _dot(at: Vector2, color: Color, radius: float) -> void:
	draw_circle(at, radius + 1, GLASS)
	draw_circle(at, radius, color)

func _cross(at: Vector2, color: Color) -> void:
	draw_line(at + Vector2(-4, -4), at + Vector2(4, 4), color, PX)
	draw_line(at + Vector2(-4, 4), at + Vector2(4, -4), color, PX)

func _machine(at: Vector2, flash: bool) -> void:
	var body := Rect2((at - Vector2(4, 4)).snapped(Vector2(PX, PX)), Vector2(8, 8))
	draw_rect(body, GLASS)
	draw_rect(body, BLAST if flash else MACHINE, false, PX)
	draw_rect(Rect2(body.get_center() - Vector2(1, 1), Vector2(2, 2)), MACHINE)

## A dark mass with a 1 px neon edge, shaped by the state.
func _matter(at: Vector2, state: Dictionary, t: float) -> void:
	if state["shape"] == "gone": return
	var edge: Color = NEON[state["material"]]
	if state["scald"]: edge = SCALD
	var fill: Color = Color(edge.darkened(0.78), 0.92)
	match state["shape"]:
		"orb":
			draw_circle(at, 9, fill)
			draw_arc(at, 9, 0, TAU, 12 if state["material"] == "ice" else 32, edge, PX)
			if state["material"] == "water": draw_arc(at + Vector2(-1, -1), 6, t, t + PI, 16, edge, PX)
			else: draw_line(at + Vector2(-5, -5), at + Vector2(4, 5), edge, PX)
		"patch":
			var points := _ellipse(at, Vector2(16, 11))
			draw_colored_polygon(points, fill)
			draw_polyline(points, edge, PX)
			if state["hard"]: draw_polyline(_ellipse(at, Vector2(12, 7)), edge, PX)
		"wall":
			var bar := Rect2(at - Vector2(3, 20), Vector2(6, 40))
			draw_rect(bar, fill)
			draw_rect(bar, edge, false, PX)
			if state["hard"]: draw_rect(bar.grow(2), edge, false, PX)
		"cloud":
			for offset: Vector2 in [Vector2(-7, 2), Vector2(6, 3), Vector2(0, -5)]:
				draw_circle(at + offset, 10, fill)
			for offset: Vector2 in [Vector2(-7, 2), Vector2(6, 3), Vector2(0, -5)]:
				draw_arc(at + offset, 10, 0, TAU, 20, edge, PX)
		"fragments":
			for i: int in 7:
				var angle: float = i * 0.9
				var p: Vector2 = at + Vector2(cos(angle), sin(angle)) * (5.0 + (i % 3) * 4.0)
				draw_colored_polygon(PackedVector2Array([p + Vector2(0, -3), p + Vector2(3, 2), p + Vector2(-3, 2)]), edge)
	if state["coat"] > 0:
		for i: int in 4 * state["coat"]:
			var angle: float = i * TAU / (4 * state["coat"]) + t * 0.7
			draw_rect(Rect2((at + Vector2(cos(angle), sin(angle)) * 14.0).snapped(Vector2(PX, PX)), Vector2(PX, PX)), BRASS)
	if state["charge"] > 0 and fmod(t, 0.4) < 0.25:
		for i: int in state["charge"] + 1:
			var angle: float = i * 2.3 + floorf(t * 6.0)
			var p: Vector2 = (at + Vector2(cos(angle) * 15.0, sin(angle) * 9.0)).snapped(Vector2(PX, PX))
			draw_polyline(PackedVector2Array([p, p + Vector2(2, 3), p + Vector2(-1, 4), p + Vector2(1, 7)]), SPARK, PX)
	if state["well"]: _rings(at, Recipe.WELL_RADIUS * PX_PER_M, -1.0, t)
	if state["repel"]: _rings(at, Recipe.REPEL_RADIUS * PX_PER_M, 1.0, t)

## A node's properties as 7x7 marks, left to right: temperature, charge, gravity, steam. Returns
## where they end.
func _props(at: Vector2, state: Dictionary) -> float:
	if state.is_empty() or state["shape"] == "gone": return at.x
	var marks: Array[String] = []
	if state["material"] == "water" or state["material"] == "ice": marks.append("mojado")
	if state["material"] == "steam": marks.append("vapor")
	if state["material"] == "fire" and state.get("fierce", false): marks.append("caliente")
	var temp: int = state["temp"]
	for i: int in absi(temp): marks.append("caliente" if temp > 0 else "frio")
	for i: int in int(state["charge"]): marks.append("carga")
	if state["grav"] > 0: marks.append("pozo")
	elif state["grav"] < 0: marks.append("repele")
	var x: float = at.x
	for mark: String in marks:
		draw_texture_rect(Kit.prop(mark), Rect2(Vector2(x, at.y), Vector2(7, 7) * PX), false)
		x += 6 * PX
	return x

## A 1 px arc from `from` to `to`, jittering.
func _zap(from: Vector2, to: Vector2, t: float) -> void:
	var points := PackedVector2Array([from])
	for i: int in range(1, 5):
		var along: Vector2 = from.lerp(to, i / 5.0)
		points.append(along + Vector2(0, sin(t * 53.0 + i * 2.1) * 4.0))
	points.append(to)
	draw_polyline(points, SPARK, PX)

func _ellipse(at: Vector2, radius: Vector2) -> PackedVector2Array:
	var points := PackedVector2Array()
	for i: int in 21: points.append(at + Vector2(cos(i * TAU / 20) * radius.x, sin(i * TAU / 20) * radius.y))
	return points

## Gravity bands: inward for a well, outward for a repulsor.
func _rings(at: Vector2, radius: float, flow: float, t: float) -> void:
	draw_arc(at, radius, 0, TAU, 40, Color(GRAVITY, 0.9), PX)
	for i: int in 3:
		var phase: float = fposmod(i / 3.0 + t * 0.5 * flow, 1.0)
		draw_arc(at, maxf(3.0, radius * phase), 0, TAU, 32, Color(GRAVITY, 0.45), PX)

## The armed mark: a small blinking tick over matter waiting for its THEN.
func _armed(at: Vector2, t: float) -> void:
	if fmod(t, 0.5) < 0.3: draw_rect(Rect2((at + Vector2(-2, -26)).snapped(Vector2(PX, PX)), Vector2(2, 2) * PX), Kit.RAMPS["then"][2])

## The THEN playing out from `at`, `elapsed` seconds after its moment.
func _effect(then: String, state: Dictionary, at: Vector2, machine: Vector2, rect: Rect2, elapsed: float, build: Dictionary, index: int) -> void:
	var grow: float = clampf(elapsed / 0.5, 0, 1)
	var fade: Color = Color(1, 1, 1, 1.0 - clampf((elapsed - 0.5) / 0.6, 0, 1))
	if state["coat"] > 0 and then == "detonar": draw_arc(at, Recipe.BURST_RADIUS * PX_PER_M * (1.2 + 0.3 * (state["coat"] - 1)) * grow, 0, TAU, 32, BRASS * fade, PX)
	match then:
		"fragmentos":
			match state["material"]:
				"ice":
					for i: int in 5:
						var spread: Vector2 = Vector2(0, (i - 2) * 3.0)
						var p: Vector2 = at.lerp(machine + spread, grow)
						draw_colored_polygon(PackedVector2Array([p + Vector2(3, 0), p + Vector2(-2, -2), p + Vector2(-2, 2)]), NEON["ice"] * fade)
				"scrap":
					for i: int in 5:
						var spread: Vector2 = Vector2(0, (i - 2) * 3.0)
						var p: Vector2 = at.lerp(machine + spread, grow)
						draw_rect(Rect2(p - Vector2(1, 1), Vector2(3, 2)), NEON["scrap"] * fade)
				"current": if grow < 1.0: _zap(at, machine, elapsed)
				"fire":
					for i: int in 10:
						var p: Vector2 = at + Vector2.from_angle(i * TAU / 10 + 0.3) * Recipe.SPLASH_RADIUS * PX_PER_M * grow
						draw_rect(Rect2(p, Vector2(PX, PX)), NEON["fire"] * fade)
				"water": draw_arc(at, Recipe.SPLASH_RADIUS * PX_PER_M * grow, 0, TAU, 32, NEON["water"] * fade, PX)
				"steam": draw_arc(at, Recipe.SPLASH_RADIUS * PX_PER_M * grow, 0, TAU, 32, SCALD * fade, PX)
		"estallar":
			draw_arc(at, Recipe.BURST_RADIUS * PX_PER_M * grow, 0, TAU, 32, NEON[state["material"]] * fade, PX)
		"detonar":
			if state["coat"] > 0: draw_arc(at, Recipe.BURST_RADIUS * PX_PER_M * grow, 0, TAU, 32, BRASS * fade, PX)
		"colapso":
			if elapsed < 0.6:
				for i: int in 8:
					var dir := Vector2.from_angle(i * TAU / 8)
					var r: float = Recipe.WELL_RADIUS * PX_PER_M * (1.0 - elapsed / 0.6)
					draw_line(at + dir * r, at + dir * maxf(r - 8, 0), GRAVITY, PX)
			else:
				draw_arc(at, Recipe.BURST_RADIUS * PX_PER_M * clampf((elapsed - 0.6) / 0.4, 0, 1), 0, TAU, 32, BLAST * fade, PX)
		"cadena":
			var target: int = Build.relay_target(build["routines"], index)
			var box := Rect2(rect.end - Vector2(34, 16) * PX, Vector2(30, 13) * PX)
			Kit.notched(self, box, GLASS, LINK)
			Kit.text(self, box.position + Vector2(4, 0) * PX, ("→ %d" % (target + 1)) if target >= 0 else "→ ·", LINK)
			if target >= 0:
				var p: Vector2 = at.lerp(box.get_center(), clampf(elapsed / 0.7, 0, 1))
				draw_line(at, p, Color(LINK, 0.6), PX)
				draw_rect(Rect2(p - Vector2(2, 2), Vector2(4, 4)), BLAST)
