## Small data catalog: material transitions are explicit, multi-step recipes are not.
extends RefCounted
const MATERIALS := {
	"water": {"spawnable": true, "initial_states": ["wet"], "properties": ["reshapeable", "coatable"], "color": Color(0.12, 0.22, 0.25), "integrity": 20.0},
	"ice": {"spawnable": false, "initial_states": ["frozen"], "properties": ["solid", "breakable", "brittle", "coatable"], "color": Color(0.65, 0.76, 0.77), "integrity": 20.0},
	# Steam keeps the water's identity, so condensing gives the same construct back. It hides
	# whatever is behind it from line of sight, drifts when pushed, and is never solid.
	"steam": {"spawnable": false, "initial_states": ["vapor"], "properties": ["obscuring", "movable", "coatable"], "color": Color(0.62, 0.68, 0.7), "integrity": 20.0},
	# Burning fuel, taken from the yard's drums: it lights what it touches, eats its own fuel and is
	# gone, and the air in it carries a charge.
	"fire": {"spawnable": true, "initial_states": ["burning"], "properties": ["coatable", "conductive"], "color": Color(0.9, 0.42, 0.14), "integrity": 20.0},
	# Current drawn from a transformer: it looks for ground, jumping to the nearest body, and is
	# spent one discharge at a time.
	"current": {"spawnable": true, "initial_states": ["live"], "properties": ["coatable", "conductive"], "color": Color(0.96, 0.9, 0.42), "integrity": 20.0},
	# Scrap off a wreck or a junk heap: heavy, metal, it conducts, holds heat and breaks into shrapnel.
	"scrap": {"spawnable": true, "initial_states": [], "properties": ["solid", "breakable", "brittle", "coatable", "conductive"], "color": Color(0.32, 0.28, 0.24), "integrity": 30.0},
}
## Where each routine can draw from: the substance, and the materials of it that can be taken.
const SUBSTANCES := ["water", "fire", "current", "scrap"]
static func substance_of(material: String) -> String:
	return "water" if material in ["water", "ice", "steam"] else material
## Two directions around the same phase cycle: ice <- water <- steam, and back.
const TRANSITIONS := {
	"freeze": {"water": "ice", "steam": "water"},
	"heat": {"ice": "water", "water": "steam"},
}
## The vocabulary a routine, a manual key or a reaction may use. The host re-checks all of it.
const STEPS := ["raise", "wall", "freeze", "heat", "coat", "impact", "push", "drop"]
const TRIGGERS := ["broken", "hit", "transformed", "pulsed"]
const REACTIONS := ["push", "command", "freeze", "heat"]
## A conduit carries a reaction's pulse to one other construct of the same owner.
const LINK_RANGE := 14.0
const PULSE_SPEED := 9.0
const COATINGS := {"nanites": {"requires": "coatable", "commands": ["detonate"], "radius": 4.0, "damage": 18.0}}
## Nanites suspended in a cloud burn as one front: the same energy over a wider sphere.
const SUSPENDED_BLAST_RADIUS := 1.6
## Shape each phase settles into, when the phase has one of its own.
const STEAM_SIZE := Vector3(4.4, 2.6, 3.4)
const PATCH_SIZE := Vector3(4, 0.12, 3)
const STEAM_LIFETIME := 7.0
## Raise changes elevation; wall explicitly changes shape. A 1.4 m orb holds the patch's volume.
const ORB_SIZE := Vector3(1.4, 1.4, 1.4)
const HOLD_HEIGHT := 0.55
const WALL_SIZE := Vector3(4, 1.8, 0.2)
const FIELD_ACCEL := 36.0
const FIELD_SPEED := 7.0
## Standing water is counted in draughts: one routine takes one, and a puddle's size follows what
## it holds. Water is never made, only moved: a routine draws it from the yard and, spent, it
## lands back on the floor as a puddle.
const MAX_VOLUME := 3.0
## A drum's fire, a transformer's terminals: small sources that are not puddles on the floor.
const SOURCE_SIZE := Vector3(1.4, 1.0, 1.4)
## How long drawn fire burns before its fuel is gone, and how much longer stoking keeps it.
const FIRE_LIFETIME := 7.0
const STOKE := 4.0
## Discharges a draught of current holds.
const CURRENT_CHARGE := 2
const MAX_CURRENT := 3

static func puddle_size(volume: float) -> Vector3:
	var spread: float = sqrt(clampf(volume, 0.35, MAX_VOLUME))
	return Vector3(PATCH_SIZE.x * spread, PATCH_SIZE.y, PATCH_SIZE.z * spread)

## Whether a routine may draw from this record: liquid water lying still on the floor, owned by
## the yard or left by the crew, and nothing a player has set working: no routine taking shape, no
## reaction armed, no charge, field or coat on it.
## Fire and current are drawn only from the yard's own (a drum, a transformer, a fire the yard
## lit); scrap from any pile lying still.
static func drawable(record: Dictionary, substance: String = "water") -> bool:
	if record["material"] != substance or record["shape"] != "patch" or record.get("suspended", false): return false
	if record.get("forming", false) or record.has("reaction") or record["velocity"].length_squared() > 0.01: return false
	if int(record.get("grav", 0)) != 0 or not record["attachments"].is_empty(): return false
	if substance == "current": return true
	return int(record.get("charge", 0)) == 0

static func can_raise(record: Dictionary) -> bool:
	return not record.get("suspended", false) and record["shape"] in ["patch", "cloud"]

static func can_wall(record: Dictionary) -> bool:
	return record["material"] in ["water", "ice", "fire", "current", "scrap"] and record["shape"] in ["patch", "orb"]

static func can_drop(record: Dictionary) -> bool:
	return record.get("suspended", false) or record["shape"] in ["wall", "cloud"]

static func field_mobile(record: Dictionary) -> bool:
	return record["shape"] != "wall"

static func field_velocity(velocity: Vector3, gap: Vector3, radius: float, power: float, delta: float) -> Vector3:
	var distance: float = gap.length()
	if distance < 0.15 or distance > radius: return velocity
	return (velocity + gap.normalized() * FIELD_ACCEL * power * (1.0 - 0.5 * distance / radius) * delta).limit_length(FIELD_SPEED * power)

static func has_property(record: Dictionary, property: String) -> bool:
	if property == "movable" and record.get("suspended", false): return true
	if property in record.get("properties", []):
		return true
	return property in MATERIALS[record["material"]]["properties"]

# --- Properties --------------------------------------------------------------------------------
# Matter and machines share a short vocabulary: `temp` (-2 frozen .. +2 burning), `wet`, `charge`
# (0..2), `grav` (-1 repels, +1 pulls), `mass` and `code` (reserved). Water's phase follows from
# its temp, and the old flags read off the properties: hard ice is -2, scalding steam +2, a well
# is grav +1, a repulsor grav -1.
const PHASE_TEMP := {"ice": -1, "water": 0, "steam": 1, "fire": 2, "current": 0, "scrap": 0}
const MASS := {"water": 1.0, "ice": 2.0, "steam": 0.2, "fire": 0.1, "current": 0.0, "scrap": 3.0}

static func phase(temp: int) -> String:
	return "ice" if temp <= -1 else ("steam" if temp >= 1 else "water")

static func temp_of(record: Dictionary) -> int:
	return int(record.get("temp", PHASE_TEMP.get(record["material"], 0)))

static func mass_of(record: Dictionary) -> float:
	return float(record.get("mass", MASS.get(record["material"], 1.0)))

## How hard a field pulls or throws: gravity grows with the mass at its heart, so a well of scrap
## drags hardest, ice next, water as before, and steam, fire or current barely tug.
const MAX_WELL_MASS := 6.0
static func gravity(record: Dictionary) -> float:
	return float(record.get("grav_power", 1.0)) * clampf(0.5 + 0.5 * mass_of(record), 0.5, 2.5)

## "well", "repel" or "" from the record's gravity.
static func field(record: Dictionary) -> String:
	var grav: int = int(record.get("grav", 0))
	return "well" if grav > 0 else ("repel" if grav < 0 else "")

static func hard(record: Dictionary) -> bool:
	return record["material"] == "ice" and temp_of(record) <= -2

static func scald(record: Dictionary) -> bool:
	return record["material"] == "steam" and temp_of(record) >= 2

## Impulse: what a moving thing does to what it hits, mass times speed. Shards weigh half a sheet.
const IMPULSE := 0.85
const IMPULSE_CAP := 14.0
static func impact(record: Dictionary, speed: float) -> float:
	var mass: float = mass_of(record) * (0.5 if record["shape"] == "fragments" else 1.0)
	return minf(IMPULSE_CAP, mass * speed * IMPULSE)
